# Violation reports (`cora.security.violation/v1`)

`violation.schema.json` (repo root) is the contract. A report says that a monitored task contacted
a blocklisted tracker or rogue address, and what Cora did about it. See
`examples/violation.example.json`.

## Fields

| Field | Meaning |
|---|---|
| `schema` | always `cora.security.violation/v1`. A breaking change gets a new id, never an edit. |
| `report_id` | random 128-bit id, unrelated to any local event |
| `observed_hour` | UTC, **truncated to the hour** |
| `task_ref` | 12 hex chars: `HMAC-SHA256(local secret salt, task name)`. Lets one reporter's repeat reports be recognised without revealing the task |
| `process` | executable basename, or `null` (null unless the operator opts in) |
| `violation.type` / `list` / `entry` | `tracker_domain` or `rogue_subnet`; which list; the exact entry that matched |
| `violation.destination` | `ip` (**only if public**, else `null`), `port`, `ip_class` |
| `response` | `verdict`, whether it was `enforced`, any override `policy`, `model_confidence` (rounded to 0.1) |

## What is never in a report

Hostname, user, pid, virtual IP, cgroup/task name, command line, local ports or addresses, private
or LAN destination addresses, the model's free-text reason, exact timestamps.

The salt lives outside the report directory (`~/.config/cora/report_salt`, mode 0600 by default), so
a zipped report folder does not let anyone brute-force task names from `task_ref`.

## Validate

```
python3 -c "import json,jsonschema; s=json.load(open('violation.schema.json')); \
jsonschema.validate(json.load(open('examples/violation.example.json')), s); print('ok')"
```

Reports are written locally and are never sent automatically; review, then file with
`gh issue create --repo nkaralus/cora-security --body-file <report>.md`.
